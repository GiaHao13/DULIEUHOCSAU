# Nhóm 5 - Image Classificaion Using CNN on Cifar-10


## Giới thiệu

- Dự án "Image Classification Using CNN" tập trung vào việc áp dụng mạng nơ-ron tích chập (CNN - Convolutional Neural Network) để giải quyết vấn đề phân loại hình ảnh. Mục tiêu chính là xây dựng một hệ thống có khả năng tự động học và nhận diện đối tượng trong hình ảnh với độ chính xác cao.
  
## Tính năng tải hình ảnh từ bên ngoài để dự đoán

- Ctrl+Enter để chạy , giao diện hiện ra Choose File và Cancel Upload
  ![image](https://github.com/user-attachments/assets/3ba06907-ea13-4c47-a642-f5d2b01ba70b)
- Tải lên hình ảnh: Nhấn nút **"Choose files"** để chọn một hình ảnh từ máy tính của bạn. Hình ảnh đã tải lên sẽ hiển thị trực tiếp trên giao diện Google Colab.
- ![image](https://github.com/user-attachments/assets/fdbf8a57-0fb6-4879-b04f-f83271afffbc)
- Dự đoán hình ảnh với độ chính xác dự đoán
- ![image](https://github.com/user-attachments/assets/eeadbb05-ba3d-4552-ad15-7894520d4b67)
- Tự động save images sau khi dự đoán
  ![image](https://github.com/user-attachments/assets/e1f34490-0f8c-43c5-80e6-dba30ba699d6)

## Lời Cảm Ơn

Cảm ơn thầy Nguyễn Thái Anh và Trường Đại học Văn Lang đã tạo điều kiện để Nhóm 5 chúng em thực hiện đồ án một cách suôn sẻ. Trong quá trình làm còn nhiều thiếu sót nhưng những lời góp ý và sự giúp đỡ của thầy, nhóm chúng em đã có thể hoàn thành đồ án một cách trọn vẹn.

**Thành viên Nhóm 5**
|STT|Tên thành viên|MSSV|Nhiệm vụ|
|---|--------------|----|--------|
|1|Nguyễn Hữu Trường| 207CT65867|Thành viên|
|2|Thái Quốc Bảo|207CT09955|Thành viên|
|3|Đào Duy Luân|2174802010599|Thành viên|
|4|Lê Gia Hào|207CT65580|Thành viên|
